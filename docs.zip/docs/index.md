--- 
title: "Tutorial 2: An introduction to the main functionalities of the Emulatorr package"
author: "Andy Iskauskas, Danny Scarponi"
site: bookdown::bookdown_site
output:
    bookdown::pdf_book:
        includes:
            in_header: header.tex
    bookdown::gitbook:
        config:
            sharing: null
        css: 'style.css'
        highlight: tango
        includes:
            in_header: _toggle.html
        keep_md: TRUE
linkcolor: blue
documentclass: book
link-citations: yes
description: "An easy guide to the main functionalities of the Emulatorr package"
---







```
#> Warning: package 'SimInf' was built under R version 4.0.4
#> Warning: package 'ggplot2' was built under R version 4.0.4
```

iii

# Introduction to the model {#intro}

In this tutorial we present the main functionalities of the [emulatorr](https://github.com/Tandethsquire/emulatorr) package, using a synthetic example of an epidemiological model. Although self-contained, this tutorial is the natural continuation of Tutorial 1 (hyperlink), which gives an overview of the history matching with emulation process and shows how it works through a simple one-dimensional example. Readers that are not familiar with history matching and emulation will find Tutorial 1 particularly helpful.

The model that we chose for demonstration purposes is a stochastic <span class="abbr" title="A model consisting of four compartments 

- $S$: Susceptible individuals,
- $E$: Exposed individuals (i.e. people that are infected but not infectious yet), 
- $I$: Infectious individuals,  
- $R$: Recovered individuals, 

and four possible transitions

- $S \rightarrow E$, when a susceptible individual becomes infected, 
- $E \rightarrow I$, when an infected individual becomes infectious,
- $I \rightarrow R$, when an infectious individual recovers,
- $R \rightarrow S$, when a recovered individual becomes susceptible again.

SEIRS models are used to study those infectious diseases that do not confer permanent immunity."><abbr title="A model consisting of four compartments 

- S: Susceptible individuals,
- E: Exposed individuals (i.e. people that are infected but not infectious yet), 
- I: Infectious individuals,  
- R: Recovered individuals, 

and four possible transitions

- S to E, when a susceptible individual becomes infected, 
- E to I, when an infected individual becomes infectious,
- I to R, when an infectious individual recovers,
- R to S, when a recovered individual becomes susceptible again.

SEIRS models are suitable to study those infectious diseases that have an incubation period and do not confer permanent immunity.">
SEIRS</abbr></span>
model, with four parameters: rate of transmission between each infectious person and each susceptible person $\beta_M$; transition rate from exposed to infectious $\gamma_M$; recovery rate from infectious to recovered $\delta_M$; and a 'loss of immunity' rate from recovered to susceptible $\mu_M$.

<div class="figure" style="text-align: center">
<img src="SEIRSdiagram.png" alt="SEIRS Diagram"  />
<p class="caption">(\#fig:unnamed-chunk-3)SEIRS Diagram</p>
</div>

Expressed in terms of differential equations, the transitions are
\begin{align}
\frac{dS}{dt} &= -\frac{\beta_M S I}{N} + \mu_M R \\
\frac{dE}{dt} &= -\gamma_M E + \frac{\beta_M S I}{N} \\
\frac{dI}{dt} &= -\delta_M I + \gamma_M E \\
\frac{dR}{dt} &= -\mu_M R + \delta_M I
\end{align}
where $N$ represents the total population, $N=S+E+I+R$. For simplicity, we consider a closed population, so that $N$ is constant.

To generate runs from this model, we use [SimInf](https://cran.r-project.org/web/packages/SimInf/index.html), a package that provides a framework to conduct data-driven epidemiological modelling in realistic large scale disease spread simulations. Note that the emulatorr package is code-agnostic: although we chose SimInf for this case study, the user of emulatorr is completely free to select the package (and programming language) that most suits them to obtain simulations of their computer model. SimInf requires us to define the transitions, the compartments, and the initial population. If
we want multiple repetitions for each choice of parameters, we create a data.frame with identical rows, each of which has the same initial population. Here we will choose $50$ repetitions per choice of parameters and consider an initial population of $1000$ of whom $50$ are infected. Note that if we were to start 
with one infectious individual, there would a be a significant probability that some runs of the model would not show an epidemic (since it could happen that the only infectious person recovers before infecting other people). Choosing a relatively high number of initial infectious people helps us circumvent any problems that would come from bimodality and keep the tutorial simple. Bimodality will be dealt in the more advanced case studies. 


```r
compartments <- c("S","E","I","R")
transitions <- c(
  "S -> beta*I*S/(S+I+E+R) -> E",
  "E -> gamma*E -> I",
  "I -> delta*I -> R",
  "R -> mu*R -> S"
)
nreps <- 50
u0 <- data.frame(
  S = rep(950, nreps),
  E = rep(0, nreps),
  I = rep(50, nreps),
  R = rep(0, nreps)
)
```

We select parameter values and parse the model using the function `mparse`, which takes transitions, compartments, initial values of each compartment, parameter values and the time span to simulate a trajectory. We then run the model and plot the trajectories of interest.


```r
params <- c(beta = 0.5, gamma = 0.5, delta = 0.1, mu = 0.1)
model <- mparse(transitions = transitions, compartments = compartments, u0 = u0, gdata = params, tspan = 1:60)
result = run(model)
plot(result)
```

<img src="_main_files/figure-html/unnamed-chunk-5-1.png" style="display: block; margin: auto;" />

In order to extract the relevant information from the data provided by the SimInf run, a helper function `getOutputs` has been included in this document. It takes a data.frame of parameter sets and a list of times, and returns a data.frame of the results. We then create a data.frame `outputs` by binding the parameter values and the results obtained.


```r
points <- expand.grid(list(beta = c(0.4, 0.6),
                           gamma = c(0.4, 0.6),
                           delta = c(0.05, 0.15),
                           mu = c(0.05, 0.15)
))
results <- getOutputs(points, seq(10,30,by=5))
outputs <- data.frame(cbind(points, results))
head(outputs)
#>   beta gamma delta   mu    I10    I15    I20    I25    I30     EV10     EV15
#> 1  0.4   0.4  0.05 0.05 221.50 405.46 543.52 571.92 537.30 5.698469 7.729000
#> 2  0.6   0.4  0.05 0.05 365.70 599.28 633.32 574.88 517.78 7.225607 5.610822
#> 3  0.4   0.6  0.05 0.05 279.72 490.88 595.46 580.54 534.48 7.260588 8.011528
#> 4  0.6   0.6  0.05 0.05 464.84 664.26 634.62 562.00 510.44 8.169654 4.577007
#> 5  0.4   0.4  0.15 0.05 108.94 164.18 210.14 225.46 216.06 4.977698 6.598832
#> 6  0.6   0.4  0.15 0.05 199.56 302.46 313.72 260.48 209.50 7.484863 7.184362
#>       EV20     EV25     EV30
#> 1 6.692455 4.506137 4.242956
#> 2 4.338955 4.974998 4.811440
#> 3 5.154793 4.252850 4.251787
#> 4 4.165780 4.501462 4.414445
#> 5 6.915291 5.450934 4.659115
#> 6 4.866044 4.805986 5.270938
```

Each row of `outputs` corresponds to a parameter set and contains information regarding the number of infectious individuals $I$ for that set. Each row of column $I10$ (resp. $I15, I20, I25, I30$) contains the mean value of $I$ at time $10$ (resp. $15, 20, 25, 30$) for the $50$ runs of the relative parameter set. Similarly, columns $EV10, EV15, EV20, EV25, EV30$ provide a measure of the 
<span class="abbr" title="Running a stochastic model at a given set of parameters produces different results each time. We refer to this form of uncertainty as Ensemble Variability"><abbr title="Running a stochastic model at a given set of parameters produces different results each time. We refer to this form of uncertainty as Ensemble Variability.">
ensemble variability</abbr></span>
for each parameter set, at each desidered time: this is defined here as the standard deviation of the $50$ runs, plus $3\%$ of the range of the runs. The trained emulators outputs will be estimates of the means, while the ensemble variability will be used to quantify the uncertainty of such estimates.

Before we tackle the emulation, we need a set of `wave0` data. For this, we define a set of ranges for the parameters, and generate parameter sets using a [Latin Hypercube](https://en.wikipedia.org/wiki/Latin_hypercube_sampling) design (see fig. \@ref(fig:figlhs) for a Latin hypercube example in two dimensions). We will run the model over $80$ parameter sets; $40$ of these will be used for training while the other $40$ will form the validation set for the emulators.

<div class="figure" style="text-align: center">
<img src="LHS.png" alt="An example of Latin hypercube in two dimensions: there is only one sample point in each row and each column." width="60%" />
<p class="caption">(\#fig:figlhs)An example of Latin hypercube in two dimensions: there is only one sample point in each row and each column.</p>
</div>

Through the function `maxminLHS` we create two hypercube designs with 40 parameter sets each: one to train emulators and one to validate them. 


```r
ranges <- list(
  beta = c(0.2, 0.8),
  gamma = c(0.2, 1),
  delta = c(0.1, 0.5),
  mu = c(0.1, 0.5)
)
pts_train <- 2*(maximinLHS(40, 4)-1/2)
pts_valid <- 2*(maximinLHS(40, 4)-1/2)
r_centers <- map_dbl(ranges, ~(.[2]+.[1])/2)
r_scales <- map_dbl(ranges, ~(.[2]-.[1])/2)
pts_train <- data.frame(t(apply(pts_train, 1, function(x) x*r_scales + r_centers)))
pts_valid <- data.frame(t(apply(pts_valid, 1, function(x) x*r_scales + r_centers)))
pts <- rbind(pts_train, pts_valid)
head(pts)
#>        beta     gamma     delta        mu
#> 1 0.7253858 0.5757375 0.4098635 0.3173502
#> 2 0.4563490 0.4547064 0.3612369 0.2629990
#> 3 0.3805118 0.5178988 0.2539448 0.3085176
#> 4 0.5078035 0.3498551 0.3527162 0.2034571
#> 5 0.4844859 0.6493015 0.3242757 0.3799582
#> 6 0.4068807 0.8537545 0.1923016 0.1318259
```

Note that the first time we create `pts_train` (or `pts_valid`), we get $40$ parameter sets where each parameter value is distributed on $[-1,1]$. This is not exactly what we need, since each parameter has a different range. We therefore define `r_centers` (resp. `r_scales`) which contains the midpoint (resp. the size) of the range of each parameter. Using these two pieces of information, we re-center and re-scale `pts_train` (and `pts_valid`). 

We obtain the model runs for the parameter sets in `pts` through the `getOutputs` function. We bind the parameter sets in `pts` to the model runs and save everything in the data.frame `wave0`. 


```r
wave0 <- data.frame(cbind(pts,getOutputs(pts, seq(10,30,by=5)))) %>% 
setNames(c(names(ranges), paste0("I",seq(10,30,by=5)),paste0('EV',seq(10,30,by=5))))
head(wave0)
#>        beta     gamma     delta        mu    I10    I15    I20    I25    I30
#> 1 0.7253858 0.5757375 0.4098635 0.3173502  89.92 116.94 136.48 145.22 146.32
#> 2 0.4563490 0.4547064 0.3612369 0.2629990  37.42  41.98  47.34  48.88  49.26
#> 3 0.3805118 0.5178988 0.2539448 0.3085176  56.02  69.12  82.44  96.48 106.96
#> 4 0.5078035 0.3498551 0.3527162 0.2034571  41.38  49.10  58.82  64.18  70.02
#> 5 0.4844859 0.6493015 0.3242757 0.3799582  62.40  80.08  93.84 103.78 117.82
#> 6 0.4068807 0.8537545 0.1923016 0.1318259 120.92 171.66 206.74 214.72 216.44
#>       EV10     EV15     EV20     EV25     EV30
#> 1 5.673286 6.317488 5.603514 3.990735 5.043979
#> 2 2.954996 3.237577 3.673379 3.731541 3.725365
#> 3 3.649543 4.682559 5.332532 5.781993 6.368925
#> 4 2.685131 3.152139 4.407604 5.237344 4.687587
#> 5 4.272857 4.789298 5.847034 5.572719 5.413788
#> 6 5.806106 6.054552 5.866510 4.886092 4.979186
```

Finally, we split `wave0` into two parts: the training set, on which we will train the emulators, and a validation set, which will be used to do diagnostics of the emulators. 


```r
train0 <- wave0[1:40,1:9]
valid0 <- wave0[41:80,1:9]
```

# Perfoming a full wave of emulation and history matching

In this section we show a simple and direct way of performing a full wave of emulation and history matching (the first wave). This is done by using the function 
`full_wave`, which needs the following information:

- Training data;

- Validation data;

- A list of ranges for the parameters;

- A list with the names of the model outputs to emulate;

- The targets: for each of the model outputs to emulate, we need a pair (val, sigma) that we will use to evaluate implausibility. The 'val' component represents the mean value of the output and 'sigma' represents our uncertainty about it;

- The number of parameter sets to generate for the next wave;

- The sampling method we want to use.

We already have almost all of these pieces. We just need the model output names


```r
output_names <- paste0("I", seq(10,30, by=5))
```

and the targets:


```r
targets = list(
  I10 = list(val = 240, sigma = 12.64),
  I15 = list(val = 396, sigma = 20.49),
  I20 = list(val = 453, sigma = 23.24),
  I25 = list(val = 428, sigma = 21.99),
  I30 = list(val = 392, sigma = 20.15)
)
```

<infobutton id="displayTextunnamed-chunk-12" onclick="javascript:toggle('unnamed-chunk-12');">Show: More on how targets were set</infobutton>

<div id="toggleTextunnamed-chunk-12" style="display: none"><div class="panel panel-default"><div class="panel-body">
As our dataset is synthetic, we couldn’t rely on observed data to define our targets. Instead, we ran the model from a chosen parameter set, with a large number of repetitions. The means from the various runs provided the mean values (val), while the sigmas were defined as the sum of the ensemble variability and a term simulating the observational error. The ensemble variability was estimated as the standard deviation of the various runs, plus  3% of the range of the runs. Note that if the dataset weren't synthetic, we would also add the model discrepancy, to account for the fact that no model perfectly represents reality.</div></div></div>
  
Before performing a wave of history matching with emulation we use the `simulator_plot` function to plot runs from parameter sets in `wave0` and compare them to our targets.


```r
all_points <- list(wave0[1:9])
simulator_plot(all_points, targets)
```

<img src="_main_files/figure-html/unnamed-chunk-13-1.png" style="display: block; margin: auto;" />

We then perform the first wave of history matching:  


```r
test_full_wave <- full_wave(train0, valid0, ranges, output_names, targets, 120, sample_method = 'importance')
#> Building emulators...
#> Running diagnostics...
#> Generating new sample points...
#> [1] "Performing LH sampling with rejection..."
#> [1] "Performing line sampling..."
#> [1] "Performing importance sampling..."
```

Here we set the argument `sample_method` to 'importance', to specify that [importance sampling](https://en.wikipedia.org/wiki/Importance_sampling) should be used when selecting parameter sets for the next wave. The `full_wave` function does the following for us:

- creates `base_emulators`: these are a premilinary version of the emulators necessary to set our priors for the Bayes Linear method; 

- creates the `emulators`: these are obtained by adjusting the base emulators through the Bayes Linear update formulae;

- provides us with `new_ranges`, the parameter ranges for the next wave,

- provides us with `next_sample`, the new sample parameter sets, where the model will be run to build the next wave emulators. 

To see how the parameter space has changed after the first wave of the process, we use the function `wave_points`, which plots the old and the new set of parameters on the same pair of axis:


```r
wave_points(list(wave0, test_full_wave$next_sample), names(ranges))
```

<img src="_main_files/figure-html/unnamed-chunk-15-1.png" style="display: block; margin: auto;" />

Here `wave0` parameter sets are in yellow and the new sets are in purple. The plots in the main diagonal show the distribution of points in the two sets. In each plot the parameters that are not shown are fixed at the mid-range value. Let us take a look at the yellow and purple distributions for the delta parameter. While the distribution of points in `wave0` is rather uniform, the distribution of the new wave peaks at low values of delta and decreases to zero for large values of delta.  Similarly, if we look at the beta-mu plot, the yellow points are uniformly distributed, while the purple points are concentrated in the upper right region: this suggests that parameter sets with low values of beta and low values of mu are unlikely to give a good fit for the model.

The next plot shows that parameter sets in `next_sample` (in orange) perform considerably better than parameter sets in `wave0` (in yellow). To create the plot we bind the parameter sets in  `next_sample` with the relative model runs, that we obtain through the `getOutputs` function.


```r
next_wave <- getOutputs(test_full_wave$next_sample, seq(10,30,by=5))
wave1 <- data.frame(cbind(test_full_wave$next_sample,next_wave))%>%   
  setNames(c(names(ranges),paste0("I",seq(10,30,by=5)),   paste0("EV",seq(10,30,by=5))))
all_points <- list(wave0[1:9], wave1[1:9])
simulator_plot(all_points, targets)
```

<img src="_main_files/figure-html/unnamed-chunk-16-1.png" style="display: block; margin: auto;" />

In the following sections we will explain step by step what `full_wave` does behind the scenes. This will not only enhance the reader's overall understanding, but will also provide them with the necessary tools to have more control over the process and customise it through their judgement.

# Constructing the emulators {#buildemul}

The first task that the `full_wave` function accomplishes, is to build the emulators based on the training data. We start this section by establishing the structure of the emulators that we want to construct. We then show how to build emulators step by step. 

## Background: the structure of an emulator 
An [emulator](https://en.wikipedia.org/wiki/Emulator) is a way of representing our beliefs about the behaviour of an unknown function. In our example we have a stochastic model and we choose the unknown function to be the mean of each of the model outputs over multiple runs. Given a set of model runs, we can use the emulator to get expectation and variance for a model output at any parameter set, without the need to run the model at the chosen set. Note that more sophisticated approaches are possible when working with stochastic models: apart from the mean of outputs, other features, such as the variance or various quantiles can be approximated through emulators.

In this tutorial, we will construct an emulator for each of the model outputs separately (even though more complex techniques that combine outputs are available). The general structure of a univariate emulator is as follows:
$$f(x) = g(x)^T \beta + u(x),$$
where $g(x)$ is a vector of known deterministic regression functions, $\beta$ is a vector of regression coefficients, and $u(x)$ is a Gaussian process with zero mean. In our tutorial the correlation of the process $u(x)$ is assumed to be in the following form, for two parameter sets $x$ and $x^{\prime}$:
$$\sigma^2 \left[(1-\delta) c(x,x^{\prime}) + \delta I_{\{x=x^\prime\}}\right].$$
Here $\sigma^2$ is the (prior) emulator variance and $c(x,x^{\prime})$ is a correlation function; the simplest such function is squared-exponential
$$c(x,x^{\prime}) = \exp\left(-\sum\limits_{i}\frac{(x_{i}-x_{i}^{\prime})^2}{\theta_i^2}\right).$$
The 'nugget' term $\delta I_{\{x=x^{\prime}\}}$  operates on all the parameters in the input space and also represents the proportion of the overall variance due to the ensemble variability. This term also ensures that the covariance matrix of $u(x)$ is not ill-conditioned, making the computation of its inverse possible (a key operation in the training of emulators, see Appendix \@ref(bayes)). The $\theta_i$ hyperparameters are the correlation lengths for the emulator. The size of the correlation lengths determine how close two parameter sets must be in order for the corresponding
residual values to be highly correlated. A smaller $\theta_i$ value means that we believe
that the function is less smooth with respect to parameter $i$, and thus that the values
for the corresponding parameters $x_i$ and $x_i^{\prime}$ must be closer together in order to be highly
correlated. The simplifying assumption that all the correlation length parameters
are the same, that is $\theta_i = \theta$ for all $i$, can be made, but more sophisticated versions are of course available. In such case, the larger $\theta$ is, the smoother the local variations of the emulators will be.

<infobutton id="displayTextunnamed-chunk-17" onclick="javascript:toggle('unnamed-chunk-17');">Show: Dealing with high dimensions</infobutton>

<div id="toggleTextunnamed-chunk-17" style="display: none"><div class="panel panel-default"><div class="panel-body">
Since in this tutorial we are working with a low-dimensional input space, we chose a relatively basic structure for our emulator. Note that more complex structures may be needed when dealing with higher dimensional problems, since the complexity of the emulation process increases significantly with dimensionality. There are several ways of tackling high dimensional problems. One of these consists in reducing the number of dimensions by selecting  the variables that explain the data the most.  More info on active variables can be found in Appendix \@ref(emulstr).</div></div></div>


We would like to warn the reader that several emulator structures and  correlation functions are available.  Alternatives choices to the ones made above are discussed in Appendix \@ref(emulstr). 

## Constructing the emulators step by step
To construct the emulators, two steps are required:

1) We create a set of 'initial' emulators `ems0` by fitting a regression surface to `train0`. These simple emulators will provide us with estimates for the regression surface parameters and the basic correlation specifications;

3) The emulators `ems0` constitute our prior which we adjust to the training data through the Bayes Linear update formulae. In this way we obtain the final version of our first wave emulators: `ems0_adjusted`.

Let us now go through each step in detail.

### Step 1

The function `emulator_from_data` creates the initial emulators for us. We pass `emulator_from_data` the training data, the name of the model outputs we want to emulate, the list of parameter ranges and the ensemble variability. Taken this information, `emulator_from_data` finds both the regression parameters and the active parameters for each of the indicated model outputs. Model selection is performed through [stepwise addition or deletion](https://en.wikipedia.org/wiki/Stepwise_regression) (as appropriate), using the [AIC criterion](https://en.wikipedia.org/wiki/Akaike_information_criterion) to find the minimal best fit. Note that the default behaviour of `emulator_from_data` is to fit a quadratic regression surface. If we want instead a linear regression surface, we just need to set `quadratic=FALSE`.
We note that in principle we can insert basis functions of any form for the regression surface.


```r
evs <- apply(wave0[10:ncol(wave0)], 2, mean)
ems0 <- emulator_from_data(train0, output_names, ranges, ev=evs, lik.method = 'my')
ems0[[1]]
#> Parameters and ranges:  beta: c(0.2, 0.8); gamma: c(0.2, 1); delta: c(0.1, 0.5); mu: c(0.1, 0.5) 
#> Specifications: 
#> 	 Basis Functions:  (Intercept); beta; gamma; delta; beta:gamma; beta:delta; gamma:delta 
#> 	 Active variables:  beta; gamma; delta 
#> 	 Beta Expectation:  100.14; 94.8268; 39.3626; -104.0459; 40.5446; -71.8908; -31.4994 
#> 	 Beta Variance (eigenvalues):  0; 0; 0; 0; 0; 0; 0 
#> Correlation Structure: 
#> 	 Variance:  651.438 
#> 	 Expectation:  0 
#> 	 Correlation length:  1.241873 
#> 	 Nugget term:  0.1522625 
#> Mixed covariance:  0 0 0 0 0 0 0
```

Note that we calculated the ensemble variability `evs` taking the mean of the column $EV$ in `wave0`. The function `emulator_from_data` uses `evs` to estimate the delta parameter, i.e. the proportion of the overall variance due to the ensemble variability.

<infobutton id="displayTextunnamed-chunk-19" onclick="javascript:toggle('unnamed-chunk-19');">Show: More details about the ems0 objects</infobutton>

<div id="toggleTextunnamed-chunk-19" style="display: none"><div class="panel panel-default"><div class="panel-body">
The print statement provides an overview of the emulator specifications and correlation structure, including 

- Basis Functions: here we have the four parameters beta, gamma, delta, mu and some products of them, since we chose quadratic regression. Note that beta:mu and all pure quadratic terms (such as beta:beta) are not listed: this means that stepwise addition and deletion led to discarding them,
 
- Active variables,

- first and second order specifications for $\beta$ and $u(x)$. Note that  by default `emulator_from_data` assumes that $\text{Var}[\beta]=0$: the regression surface is known and coefficients are fixed. This explains why Beta Variance and Mixed Covariance (which shows the covariance of $\beta$ and $u(x)$) are both zero. One can set beta.var=TRUE in order to consider the beta parameters as random variables. </div></div></div>

We can plot the emulators to see how they represent the output space: the `emulator_plot` function does this for emulator expectation, variance, standard deviation, and implausibility (more on which later). Note that all functions in the emulatorr package that produce plots have a colorblind-friendly option: it is sufficient to specify `cb=TRUE`. 


```r
for (i in 1:length(ems0)) ems0[[i]]$output_name <- output_names[i]
names(ems0) <- output_names
emulator_plot(ems0)
```

<img src="_main_files/figure-html/unnamed-chunk-20-1.png" style="display: block; margin: auto;" />

The emulator expectation plots show the structure of the regression surface, which is at most quadratic in its parameters, through a 2D slice of the input space. Here parameters $\beta$ and $\gamma$ are selected and we get a plot for each model output. For each pair $(\bar \beta,\bar \gamma)$ the plot shows the expected value produced by the relative emulator at the point $(\bar \beta,\bar \gamma, \delta_{\text{mid-range}}, \mu_{\text{mid-range}})$, where $\delta_{\text{mid-range}}$ indicates the mid-range value of $\delta$ and similarly for $\mu_{\text{mid-range}}$.

To plot the emulators standard deviation we just use `emulator_plot` passing 'sd' as second argument:


```r
emulator_plot(ems0, 'sd')
```

<img src="_main_files/figure-html/unnamed-chunk-21-1.png" style="display: block; margin: auto;" />

Here we immediately see that the emulator variance (or equivalently, standard deviation) is simply constant across the parameter space for each emulated output. This is not what we want though, since one would expect emulators to be less uncertain around the parameter sets that have been evaluated by the computer model. This will be taken care of in the next step.

### Step 2

We now use the `adjust` method on our emulators to obtain the final Bayes Linear version of our `wave0` emulators:


```r
ems0_adjusted <- map(seq_along(ems0), ~ems0[[.]]$adjust(train0, output_names[[.]]))
```

Note that the `adjust` method works with the data in `train0` exactly as the function `emulator_from_data` did: it performs Bayes Linear adjustment, given the data. This function creates a new emulator object with the adjusted expectation and variance of beta as the primitive specifications, and supplies the values for the new emulator to compute the adjusted expectation and variance of $u(x)$, and the adjusted $Cov[\beta, u(x)]$. Due to the update formulae, the correlation structure now depends on where in the input space it is evaluated. 


```r
names(ems0_adjusted) <- output_names
emulator_plot(ems0_adjusted)
```

<img src="_main_files/figure-html/unnamed-chunk-23-1.png" style="display: block; margin: auto;" />

```r
emulator_plot(ems0_adjusted, params = c('gamma', 'delta'), var = 'sd')
```

<img src="_main_files/figure-html/unnamed-chunk-23-2.png" style="display: block; margin: auto;" />

We can see that the adjusted emulators more reasonably show the structure of the model. The variance has been updated: the closer the evaluation point is to a training point, the lower the variance (as it 'knows' the value at this point). In fact, evaluating these emulators at parameter sets in the training data demonstrates this fact:


```r
em_evals <- ems0_adjusted$I10$get_exp(train0[,names(ranges)])
all(abs(em_evals - train0$I10) < 10^(-12))
#> [1] TRUE
```

In the next section we will define the implausibility measure while in section \@ref(diagnostics) we will explain how to assess whether the emulators we trained are performing as we would expect them to.

# History matching using implausibility {#implau}

In this section we give more details about implausibility and its role in the history matching process. Once emulators are built, we want to use them to systematically explore the input space. For any chosen parameter set, the emulator provides us with an approximation of the corresponding model output. This value is what we need to assess the implausibility of the parameter set in question.

## The implausibility measure

For a given model output and a given target, the implausibility is defined as the difference between the emulator output and the target, taking into account all sources of uncertainty. For a parameter set $x$, the schematic form for the implausibility $I(x)$ is

$$I(x) = \frac{|f(x)-z|}{\sqrt{V_0 + V_c(x)+V_s+V_m}},$$

where $f(x)$ is the emulator output, $z$ the target, and the terms in the denominator refer to various forms of uncertainty. In particular

- $V_0$ is the variance associated with the observation uncertainty;
- $V_c(x)$ refers to the uncertainty one introduces when using the emulator output instead of the model output itself. Note that this term depends on $x$, since the emulator is more/less certain about its predictions based on how close/far $x$ is from points in the training set;
- $V_s$ is the ensemble variability and represents the stochastic nature of the model (this term is not present if the model is deterministic);
- $V_m$ is the model discrepancy, accounting for possible mismatches between the model and reality.

A very large value of $I(x)$ means that the parameter set $x$ does not provide a good match to the observed data, even factoring in the additional uncertainty that comes with the use of emulators. When $I(x)$ is not too large, then we know that $x$ might be a point of good fit, so we keep $x$ in the subsequent wave.

In this case study the uncertainty that goes into the denominator of the emulator implausibility comprises the sigma values in the `targets` list, accounting for ensemble variability and observational error, and the emulator variance at the given parameter set. Note that if our targets were not synthetic, we would also include the model discrepancy, accounting for the fact that no model perfectly represents reality.

An important aspect to consider is the choice of cut-off for the implausibility measure. The implausibility is a metric for evaluating how far out from being a good fit any parameter set is: there is no hard-and-fast rule for deciding at what point a parameter set is too implausible. A rule of thumb follows Pukelsheim's $3\sigma$ rule, a very general result which states that for any continuous unimodal distribution $95\%$ of the probability lies within $3$ sigma of the mean, regardless of asymmetry (or skewness etc). This is only the case for a single such distribution; for multiple univariate emulators it is slightly more involved. However a rough starting cut-off $m$, for $(1-\alpha)-$interval  and $N$ emulators, would be
$$m = \Phi^{-1}\left(\frac{1+(1-\alpha^{1/N})}{2}\right)$$
where $\Phi^{-1}$ is the inverse of the normal distribution CDF.

## Combining outputs together

Given multiple emulators, how do we measure overall implausibility? We want a single measure for the implausibility at a given parameter set, but for each emulator we obtain an individual value for $I$. The simplest way to combine them is to consider maximum implausibility at each parameter set:
$$I_M(x) = \max_{i=1,\dots,N}I_{i}(x),$$ where $I_i(x)$ is the implausibility at $x$ coming from the $i$th emulator. For large collections of emulators, it may be useful to instead consider the second-, or third-maximum implausibility, which also provides robustness to the failure of one or two of the emulators. Where some model outputs are deemed more important than others (for instance, putting greater weight on emulation of the peak of an epidemic), we may instead take a weighted average across the implausibity measures.

## Implausibility visualisations 

To calculate the implausibility we will use the `targets` list, which represents our observations.

The default behaviour of the diagnostics and plots we will see here is to take a cut-off of $3$ (following Pukelsheim's $3\sigma$ rule), and take maximum implausibility across the emulated outputs. For instance, to find the emulator implausibility for the first output we use the `emulator_plot` function specifying 'imp' for implausibility and passing it the target for the first output:


```r
emulator_plot(ems0_adjusted[[1]], 'imp', targets = targets[[1]])
```

<img src="_main_files/figure-html/unnamed-chunk-25-1.png" style="display: block; margin: auto;" />

This is a 2D slice through the input space: for a chosen pair $(\bar\beta,\bar\gamma)$, the plot shows the implausibility of the parameter set $(\bar\beta, \bar\gamma, \delta_{\text{mid-range}}, \mu_{\text{mid-range}})$, where $\delta_{\text{mid-range}}$ denotes the mid-range value of the delta parameter and similarly for $\mu_{\text{mid-range}}$. Parameter sets with a high implausibility (orange region) are highly unlikely to give a good fit and will be discarded when forming the parameters sets for the next wave.

Another way of visualising implausibility is through a plot lattice (image shown below). While `emulator_plot` provides us with a 2D slice through the input space, plot lattices are two dimensional plots which are projections of the full space: each pixel represents the whole of the behaviour in the non-plotted parameters. More in detail,  the upper diagonal is minimum-max implausibility: implausibility is evaluated across the whole space, and for each point in the projection the minimum of these max-implausibilities is plotted. Consider as an example the beta-mu plot (upper right corner): for each pixel in it, i.e. for each pair $(\bar \beta, \bar \mu)$, the implausibility is evaluated at $(\bar \beta, \gamma, \delta, \bar \mu, )$ for all possible values of $\gamma$ and $\delta$ and the minimum of these max-implausibilities is plotted. The lower diagonal is optical depth: this is a measure of how many points have maximum implausibility below our cutoff (in this case, 3). The lighter the colour, the higher proportion of points are acceptable. The diagonal is optical depth but for single parameters at a time. For example, the lower right corner shows that around 10% of all parameter sets that have mu equal to $0.3$ are non-implausible.

<div class="figure" style="text-align: center">
<img src="PlotLatticeWave1.png" alt="Plot lattice for first wave" width="100%" />
<p class="caption">(\#fig:unnamed-chunk-26)Plot lattice for first wave</p>
</div>

# Emulator diagnostics {#diagnostics}

For a given set of emulators, we want to assess how accurately they reflect the model outputs over the input space. In this section three standard emulator diagnostics are introduced together with functions that help us visualise them. We then analyse parameter sets that fail diagnostics.

## The three main diagnostics 

The first three diagnostics are relatively straightforward, and can be presented together. For a given validation set, we can ask the following questions:

- Within uncertainties, does the emulator output accurately represent the equivalent model output?

- What are the standardised errors of the emulator outputs in light of the model outputs?

- Does the emulator adequately classify parameter sets as implausible or non-implausible?

These are encapsulated in the `validation_diagnostics` function.


```r
which_invalid <- validation_diagnostics(ems0_adjusted, valid0, output_names, targets = targets)
```

<img src="_main_files/figure-html/unnamed-chunk-27-1.png" style="display: block; margin: auto;" /><img src="_main_files/figure-html/unnamed-chunk-27-2.png" style="display: block; margin: auto;" />

The first column of plots gives an indication of the emulator outputs against the model outputs: emulator outputs are plotted against model outputs with a $3\sigma$ interval overlaid $\text{E}(f(x)) \pm 3 \sqrt{ \text{Var}(f(x))}$. An 'ideal' emulator would exactly reproduce the model results: this behaviour is represented by the green line $f(x)=E[f(x)]$. Any parameter set whose emulated prediction lies more than $3\sigma$ away from the model output is highlighted in red. 

The second column gives the standard errors normalised by the standard deviation. We want most of these to be within $\pm 3$.

Finally, the third column compares the emulator implausibility to the equivalent model implausibility (i.e. the implausibility calculated replacing the emulator output with the model output). There are three cases to consider:

- The emulator and model both classify a set as implausible/non-implausible: this is fine. Both are giving the same classification for the parameter set.

- The emulator classifies a set as non-implausible, while the model rules it out: this is also fine. The emulator should not be expected to shrink the parameter space as much as the model does, at least not on a single wave. Parameter sets classified in this way will survive this wave, but may be removed on subsequent waves as the emulators grow more accurate on a reduced parameter space.

- The emulator rules out a set, but the model does not: these are the problem sets, suggesting that the emulator is ruling out parts of the parameter space that it should not be ruling out.

The function `validation_diagnostic`, along with producing the plots, also returns a data.frame consisting of those parameters sets which failed one or more diagnostic tests. 


```r
which_invalid
#>         beta     gamma     delta        mu
#> 57 0.5327406 0.5907357 0.1114441 0.1675240
#> 74 0.4653581 0.8759205 0.1618957 0.4554082
#> 80 0.7422379 0.7289400 0.1942019 0.1823410
```

It is often worth considering these parameter sets, particularly if they lie close to the boundary of the space: having a few parameter sets which fail diagnostics is not the end of the world, but we should at least consider whether the emulator is failing in parts of the space we would want it to be performing well on.

## Parameter sets failing diagnostics

### Visualisation

A helper for visualising problematic parameter sets is provided in the function `validation_pairs`: this gives pairs plots of the parameter sets in the validation data, colouring them by their diagnostic success (bottom left) and predicted implausibility (top right). The diagnostics part gives the maximum standardised error at each point: the standardised error is $$\frac{|\text{emulator expectation}-\text{model value}|}{\sqrt{\text{emulator variance}}}$$ for each emulated output and we maximise over the outputs. 


```r
vp <- validation_pairs(ems0_adjusted, valid0, targets)
```

<img src="_main_files/figure-html/unnamed-chunk-29-1.png" style="display: block; margin: auto;" />

We can see that the parameter sets that have larger standardised errors are indeed on the boundaries of the space, particularly on the boundary of the $(\delta,\mu)$ space. Examination of the upper half of this plot shows that a large proportion of such parameter sets will be classified as implausible, so they lie in parts of the parameter space that will have no impact on the overall history matching process.

<infobutton id="displayTextunnamed-chunk-30" onclick="javascript:toggle('unnamed-chunk-30');">Show: More options for the validation\_pairs function</infobutton>

<div id="toggleTextunnamed-chunk-30" style="display: none"><div class="panel panel-default"><div class="panel-body">
Where we are emulating multiple outputs, emulator functions make a call to `nth_implausible` with default $n=1$. This can be modified in any function call that uses it. For instance, the above diagnostic plot will consider minimum implausibility in its upper plots if we set $n$ to be the number of emulators:

```r
vp2 <- validation_pairs(ems0_adjusted, valid0, targets, n=length(ems0))
```

<img src="_main_files/figure-html/unnamed-chunk-59-1.png" style="display: block; margin: auto;" />
</div></div></div>

### Space removed function 

One way we can get a feel for what cut-off value is reasonable is via the `space_removed` function, which for a given set of emulators will determine how much of the input space will be removed by a particular implausibility cut-off.  By default, `space_removed`  shows the percentage of space that is removed by a specific wave when:

- the sigma values in `targets` are exactly the values provided by the modeller,

- the sigma values in `targets` are $80\%$ (resp. $90\%, 110\%, 120\%$) of the values provided by the modeller. 


```r
space_removed(ems0_adjusted, valid0, targets) + geom_vline(xintercept = 3, lty = 2) + geom_text(aes(x=3, label="x=3",y=0.33), colour="black", angle=90, vjust = 1.2, text=element_text(size=11))
#> Warning: Ignoring unknown parameters: text
```

<img src="_main_files/figure-html/unnamed-chunk-31-1.png" style="display: block; margin: auto;" />

A cut-off of $3$ here, using maximum implausibility, would be sufficient to remove more than $90\%$ of the current parameter space. This is a reasonable level of removal for a first wave: however, if the expected amount of removal was much lower we could consider whether it is sensible to reduce the cut-off.

<infobutton id="displayTextunnamed-chunk-32" onclick="javascript:toggle('unnamed-chunk-32');">Show: More details on the space\_removed function</infobutton>

<div id="toggleTextunnamed-chunk-32" style="display: none"><div class="panel panel-default"><div class="panel-body">
We can also consider what would happen if we were to modify the emulator variances or the 
<span class="abbr" title="The correlation lengths are hyperparameters that appear in the structure of the emulators. They determine how close two parameter sets must be in order for the corresponding residual values to be highly correlated. Large values for the correlation lenghts are chosen if we believe the model to be a smooth function of the parameters."><abbr title="The correlation lengths are hyperparameters that appear in the structure of the emulators. They determine how close two parameter sets must be in order for the corresponding residual values to be highly correlated. Large values for the correlation lenghts are chosen if we believe the model to be a smooth function of the parameters.">
correlation lengths</abbr></span>. To do this we set `modified ='var'` or `modified='corr'`. This evaluates over a fairly large set of parameter sets and has to retrain multiple sets of emulators, so does take a while to run. For the purposes of speed, here, we set `n_points` to $5$: this creates a set of $5^d$ parameter sets to evaluate over, where $d$ is the dimension of the input space. As before, the default behaviour considers steps of $10\%$ around $100\%$. Here we set the `u_mod` argument in the function call to choose different steps for the variance.

```r
space_removed(ems0_adjusted, valid0, targets, u_mod = c(0.75, 1, 1.25), modified = 'var', n_points = 5) +geom_vline(xintercept = 3, lty = 2) + geom_text(aes(x=3, label="x=3",y=0.33), colour="black", angle=90, vjust = 1.2, text=element_text(size=11))
#> Warning: Ignoring unknown parameters: text
```

<img src="_main_files/figure-html/unnamed-chunk-60-1.png" style="display: block; margin: auto;" />

```r
space_removed(ems0_adjusted, valid0, targets, modified = 'corr', n_points = 5) + geom_vline(xintercept = 3, lty = 2) + geom_text(aes(x=3, label="x=3",y=0.33), colour="black", angle=90, vjust = 1.2, text=element_text(size=11))
#> Warning: Ignoring unknown parameters: text
```

<img src="_main_files/figure-html/unnamed-chunk-60-2.png" style="display: block; margin: auto;" />

We can see that changing the correlation lengths has a minimal impact on the resultant space reduction: this should not be surprising in this case, as the regression part of the emulators (i.e. the $g(x)\beta$ term) is sufficient to capture much of the dynamics of the system:

```r
map_dbl(ems0, ~summary(.$model)$adj.r.squared)
#>       I10       I15       I20       I25       I30 
#> 0.9276360 0.9280452 0.8952629 0.8638161 0.8686077
```

The adjusted $R^2$ of the linear models are all high, so the correlation structure is having to do very little 'work' for the emulators to match the training data. If we instead have a model where the linear part cannot accurately represent the model output surface, the choice of correlation lengths would be a much more important choice, and the final plot above would be a much stronger indicator of suitability.</div></div></div>

The diagnostics here give an indication of the suitability of the emulators in emulating the outputs at this wave. If there are particular model outputs for which the emulators do not give a good fit, then we can modify the specifications for that emulator directly (for example, modifying the correlation length, the variance, or the regression surface) and re-train; if the emulator simply cannot provide a good fit to a model output, we can choose not to emulate this output for the wave in question: this is one of the benefits of the history matching approach in that we can use subsets of the outputs at each wave. 

# Constructing the next wave of the history match: point generation {#newpoints}

Having generated emulators based on `wave0` data, evaluated their suitability, and considered a means by which to rule out parameter sets, we can now produce a new set of parameter sets to pass to the model. 

This section is divided in two parts:

1) We first see how to generate new sets of parameters (that will be used to train wave 1 emulators);

2) We then compare the performance of the initial parameter sets with the new parameter sets. In other words, we ask: do the model outputs at the new parameter sets match the observations better than the model outputs at the initial parameter sets?

## Generating sets of parameters for the next wave

The function `generate_new_runs` is designed to generate new sets of parameters; its default behaviour is as follows.

- If no prior parameter sets are provided, a set is generated using a [Latin Hypercube Design](https://en.wikipedia.org/wiki/Latin_hypercube_sampling), rejecting implausible parameter sets;
- Pairs of parameter sets are selected at random and more sets are sampled from lines connecting them, with particular importance given to those that are close to the non-implausible boundary;
- Using these as seeding points, more parameter sets are generated using [importance sampling](https://en.wikipedia.org/wiki/Importance_sampling) to attempt to fully cover the non-implausible region.

All of these steps can be overridden or modified, but the default behaviour allows for a good rudimentary search of the non-implausible space.


```r
new_points <- generate_new_runs(ems0_adjusted, ranges, n_points = 120, z = targets)
#> [1] "Performing LH sampling with rejection..."
#> Only 119 points generated.
#> 
#> [1] "Performing line sampling..."
#> [1] "Performing importance sampling..."
plot(new_points, pch = 16, cex = 0.5)
```

<img src="_main_files/figure-html/unnamed-chunk-33-1.png" style="display: block; margin: auto;" />

We can start to see the structure of the non-implausible region, here. The `wave_points` function provides a better indication of the difference between the two sets of wave data.


```r
wave_points(list(wave0, new_points), in_names = names(ranges))
```

<img src="_main_files/figure-html/unnamed-chunk-34-1.png" style="display: block; margin: auto;" />

Here `wave0` parameter sets are in yellow and `new_points` (i.e. new parameter sets) are in purple. The plots in the main diagonal show the distribution of parameter sets in `wave0` and that of `new_points`. 

## Comparing new and old parameter sets

Now we can put `new_points` into the model and obtain the model outputs:


```r
next_wave <- getOutputs(new_points, seq(10,30,by=5))
```

Binding together `new_points` and `next_wave` we obtain `wave1`, the full data for the next wave.

We can see how much better the `wave1` parameter sets perform compared to the original `wave0` parameter sets using `simulator_plot`.


```r
wave1 <- data.frame(cbind(new_points,next_wave))%>%   
  setNames(c(names(ranges),paste0("I",seq(10,30,by=5)),   paste0("EV",seq(10,30,by=5))))
all_points <- list(wave0[1:9], wave1[1:9])
simulator_plot(all_points, targets)
```

<img src="_main_files/figure-html/unnamed-chunk-36-1.png" style="display: block; margin: auto;" />

We can see that, compared to the space-filling random parameter sets used to train the first emulators, the new parameter sets are in much closer agreement with our targets. Subsequent waves, trained on these new parameter sets, will be more confident in the new non-implausible region and will therefore refine the region in light of the greater certainty.


# Further waves

We follow the same procedure for subsequent waves, with a couple of caveats.

## Next wave: wave 1 {#wave1}

### Training wave 1 emulators 

First of all we train a new set of emulators, in the same way we did for `ems0`:


```r
sampling <- sample(nrow(wave1), 40)
train1 <- wave1[sampling,1:9]
valid1 <- wave1[!seq_along(wave1[,1])%in%sampling,1:9]
new_ranges <- map(names(ranges), ~c(min(wave1[,.]), max(wave1[,.]))) %>% setNames(names(ranges))
evs <- apply(wave1[10:ncol(wave0)], 2, mean)
ems1 <- emulator_from_data(train1, output_names, ranges, ev=evs)
for (i in 1:length(ems1)) ems1[[i]]$output_name <- output_names[i]
ems1_adjusted <- map(seq_along(ems1), ~ems1[[.]]$adjust(train1, output_names[[.]]))
names(ems1_adjusted) <- output_names
```

### Evaluating implausibility across all waves

We can apply diagnostics to this as before, using `valid1` as the validation set. Assuming the diagnostics are acceptable, we  then proceed to consider implausibility - however, we need the implausibility over the whole input space, and the new emulators have only been trained on a subset thereof. We must therefore consider implausibility across all waves, rather than just the wave under consideration at the time.


```r
all_waves <- c(ems0_adjusted, ems1_adjusted)
all_targets <- c(targets, targets)
emulator_plot(all_waves, var = 'maximp', targets = all_targets)
```

<img src="_main_files/figure-html/unnamed-chunk-38-1.png" style="display: block; margin: auto;" />

This may seem an unwieldy way to approach this (and it is, at present); however, it is important to remember that the number of emulators at each wave may not be the same; for example, if we have had to remove a model output at wave 1, then the targets would be accordingly changed. In this illustration case, we did not have to worry about doing so since we have assumed that all targets can be emulated.

If we compare the implausibility plot we just obtained with the implausibility plot from the previous wave, we see that the red area has increased significantly: this shows that wave 1 is shrinking down the non-implausible space, exactly as we expected.

The remainder of the analysis proceeds much as in the first wave. In generating new parameter sets, we would of course provide all_waves to the point generation function.


```r
new_new_points <- generate_new_runs(all_waves, ranges, n_points = 120, z = all_targets)
#> [1] "Performing LH sampling with rejection..."
#> Only 38 points generated.
#> 
#> [1] "Performing line sampling..."
#> [1] "Performing importance sampling..."
plot(new_new_points, pch = 16, cex = 0.5)
```

<img src="_main_files/figure-html/unnamed-chunk-39-1.png" style="display: block; margin: auto;" />

We can compare the distribution of parameter sets at the end of `wave0` with that of parameter sets at the end of `wave1`:


```r
wave_points(list(wave1, new_new_points), in_names = names(ranges))
```

<img src="_main_files/figure-html/unnamed-chunk-40-1.png" style="display: block; margin: auto;" />

The last step is to create `wave2`, that will be used to train
`wave2` emulators.


```r
next_next_wave <- getOutputs(new_new_points, seq(10,30,by=5))
wave2 <- data.frame(cbind(new_new_points,next_next_wave))%>%   
  setNames(c(names(ranges),paste0("I",seq(10,30,by=5)),   paste0("EV",seq(10,30,by=5))))
```

Through the `simulator_plot` function we see how much better the `wave2` parameter sets perform compared to  `wave1` and `wave0` parameter sets.


```r
all_points <- list(wave0[1:9], wave1[1:9], wave2[1:9])
simulator_plot(all_points, targets, palette=c("#F9F920", "#FA8816","#C98CFF"))
```

<img src="_main_files/figure-html/unnamed-chunk-42-1.png" style="display: block; margin: auto;" />

Next waves of the process can be produced simply repeating all the steps in section \@ref(wave1).

## Next wave: wave 2

### Training wave 2 emulators 


```r
sampling <- sample(nrow(wave2), 40)
train2 <- wave2[sampling,1:9]
valid2 <- wave2[!seq_along(wave2[,1])%in%sampling,1:9]
new_new_ranges <- map(names(ranges), ~c(min(wave2[,.]), max(wave2[,.]))) %>% setNames(names(ranges))
evs <- apply(wave2[10:ncol(wave0)], 2, mean)
ems2 <- emulator_from_data(train2, output_names, ranges, ev=evs)
for (i in 1:length(ems2)) ems2[[i]]$output_name <- output_names[i]
ems2_adjusted <- map(seq_along(ems2), ~ems2[[.]]$adjust(train2, output_names[[.]]))
names(ems2_adjusted) <- output_names
```

### Evaluating implausibility across all waves

As before, we need to consider implausibility across all waves, rather than just the wave under consideration at the time.


```r
all_waves <- c(ems0_adjusted, ems1_adjusted, ems2_adjusted)
all_targets <- c(targets, targets, targets)
emulator_plot(all_waves, var = 'maximp', targets = all_targets)
```

<img src="_main_files/figure-html/unnamed-chunk-44-1.png" style="display: block; margin: auto;" />

To generate new parameter sets:


```r
new_new_new_points <- generate_new_runs(all_waves, ranges, n_points = 120, z = all_targets)
#> [1] "Performing LH sampling with rejection..."
#> Only 26 points generated.
#> 
#> [1] "Performing line sampling..."
#> [1] "Performing importance sampling..."
plot(new_new_new_points, pch = 16, cex = 0.5)
```

<img src="_main_files/figure-html/unnamed-chunk-45-1.png" style="display: block; margin: auto;" />

We now create `wave3`:


```r
next_next_next_wave <- getOutputs(new_new_new_points, seq(10,30,by=5))
wave3 <- data.frame(cbind(new_new_new_points,next_next_next_wave))%>%   
  setNames(c(names(ranges),paste0("I",seq(10,30,by=5)),   paste0("EV",seq(10,30,by=5))))
```

Through the `simulator_plot` function we check how much better the `wave3` parameter sets perform compared to the original `wave2` parameter sets.


```r
all_points <- list(wave1[1:9],wave2[1:9], wave3[1:9])
simulator_plot(all_points, targets, wave_numbers=c(2,3), zero_in=FALSE, palette=c("yellow", "gold", "darkorange2")) + ylim(c(0, 600))
```

<img src="_main_files/figure-html/unnamed-chunk-47-1.png" style="display: block; margin: auto;" />

The graph shows a clear improvement in the performance of `wave3` parameter sets compared to that of `wave2` parameter sets.

Let us now take a look at the plot lattice from the first wave

<div class="figure" style="text-align: center">
<img src="PlotLatticeWave1.png" alt="Plot lattice for first wave" width="100%" />
<p class="caption">(\#fig:unnamed-chunk-48)Plot lattice for first wave</p>
</div>

and the plot lattice from the last wave

<div class="figure" style="text-align: center">
<img src="PlotLatticeWave3.png" alt="Plot lattice for third wave" width="100%" />
<p class="caption">(\#fig:unnamed-chunk-49)Plot lattice for third wave</p>
</div>

The optical depth plots (lower diagonal) shos that the proportion of acceptable points for the  third wave is considerably smaller than that for the first wave.

## Next wave: wave 3

### Training wave 3 emulators 


```r
sampling <- sample(nrow(wave3), 40)
train3 <- wave3[sampling,1:9]
valid3 <- wave3[!seq_along(wave3[,1])%in%sampling,1:9]
new_new_new_ranges <- map(names(ranges), ~c(min(wave3[,.]), max(wave3[,.]))) %>% setNames(names(ranges))
evs <- apply(wave3[10:ncol(wave0)], 2, mean)
ems3 <- emulator_from_data(train3, output_names, ranges, ev=evs)
for (i in 1:length(ems3)) ems3[[i]]$output_name <- output_names[i]
ems3_adjusted <- map(seq_along(ems3), ~ems3[[.]]$adjust(train3, output_names[[.]]))
names(ems3_adjusted) <- output_names
```

### Evaluating implausibility across all waves {#stoprule}

As before, we need to consider implausibility across all waves, rather than just the wave under consideration at the time.


```r
all_waves <- c(ems0_adjusted, ems1_adjusted, ems2_adjusted, ems3_adjusted)
all_targets <- c(targets, targets, targets, targets)
emulator_plot(all_waves, var = 'maximp', targets = all_targets)
```

<img src="_main_files/figure-html/unnamed-chunk-51-1.png" style="display: block; margin: auto;" />

To generate new parameter sets:


```r
new_new_new_new_points <- generate_new_runs(all_waves, ranges, n_points = 120, z = all_targets)
#> [1] "Performing LH sampling with rejection..."
#> Only 27 points generated.
#> 
#> [1] "Performing line sampling..."
#> [1] "Performing importance sampling..."
plot(new_new_new_new_points, pch = 16, cex = 0.5)
```

<img src="_main_files/figure-html/unnamed-chunk-52-1.png" style="display: block; margin: auto;" />

We now create `wave3`:


```r
next_next_next_next_wave <- getOutputs(new_new_new_new_points, seq(10,30,by=5))
wave4 <- data.frame(cbind(new_new_new_new_points,next_next_next_next_wave))%>%   
  setNames(c(names(ranges),paste0("I",seq(10,30,by=5)),   paste0("EV",seq(10,30,by=5))))
```

Through the `simulator_plot` function we check how much better the `wave3` parameter sets perform compared to the original `wave2` parameter sets.


```r
all_points <- list(wave1[1:9], wave2[1:9], wave3[1:9], wave4[1:9])
simulator_plot(all_points, targets, wave_numbers=c(3,4), zero_in=FALSE, palette=c("yellow", "gold", "darkorange", "red")) + ylim(c(0, 600))
```

<img src="_main_files/figure-html/unnamed-chunk-54-1.png" style="display: block; margin: auto;" />

We see that `wave4` parameter sets match all our targets, while `wave3` parameter sets did not always match the first one. Since all model runs at the non-implausible space in `wave4` are accurate enough (i.e. are inside the bounds for each target) we can conclude here the iterating process. It is also informative to compare the variability of the model outputs we are emulating with the emulators uncertainty. Below we show the ensemble variability and the uncertainty for `ems0` and `ems3` for each of the emulated outputs.


```r
targets$I10$sigma
#> [1] 12.64
targets$I15$sigma
#> [1] 20.49
targets$I20$sigma
#> [1] 23.24
targets$I25$sigma
#> [1] 21.99
targets$I30$sigma
#> [1] 20.15
sigmas0 <- map_dbl(ems0, ~.$u_sigma)
sigmas0
#>      I10      I15      I20      I25      I30 
#> 25.52328 38.71016 56.55350 65.35864 65.90110
sigmas3 <- map_dbl(ems3, ~.$u_sigma)
sigmas3
#>      I10      I15      I20      I25      I30 
#> 6.298750 6.742715 6.356497 7.913778 8.763624
```

We see that while `ems0` uncertainties (`sigmas0`) are larger than the ensemble variabilities, all `ems3` uncertainties (`sigmas3`) are smaller than the ensemble variabilities. Since the emulators variance is smaller than the uncertainty inherent to the model, the non-implausible space is unlikely to
decrease in size in the next iteration. This gives us another reason for stopping the history matching process here.

In general, another stopping criterion consists in having all the input space deemed implausible at the end of the current wave. In this situation, one deduces that there are no parameter sets that give an acceptable match with the data: in particular, this raises doubts about the adequacy of the chosen model.
Finally, we can stop the history matching process if all model runs at the non-implausible space of the current wave are accurate enough, i.e. if they are close enough to the targets.


# Glossary

**Beliefs**: In Bayesian statistics, probability expresses a degree of belief in an event. Such belief can be based either on prior knowledge or on personal beliefs about the event. 

**Correlation lengths**: The correlation lengths are hyperparameters that appear in the structure of the emulators. They determine how close two parameter sets must be in order for the corresponding residual values to be highly correlated. Large values for the correlation lenghts are chosen if the model is believed to be a smooth function of the parameters.

**Emulator output**: The data produced by executing an emulator. In each wave of the history matching process, a subset of the model outputs is selected to be emulated. 

**Ensemble variability**: The variability resulting from the stochasticity of the  model. 

**Implausibility**: A measure which evaluates the distance between the targets and the model output/emulator output at any given parameter set.

**Input space**: The set of all possible combinations of parameters.

**Model output**: Any data produced by executing a model. An example of model output in this case study is the number of infectious individuals at time $10$ (or $15, 20, 25, 30$). 

**Observed data**: The data we fit our model to, which usually comes from empirical observations. Since in this case study we work with a synthetic dataset, we prefer to use the word 'targets' rather than 'observed data'. 

**Parameter set**: An element of the input space.

**Points**: Another word for 'parameter set'.

**SEIRS model**: A model consisting of four compartments: Susceptible individuals (S), Exposed individuals (E) i.e. people that are infected but not infectious yet, Infectious individuals (I) and Recovered individuals (R). In the model four transitions are allowed:
S to E, when a susceptible individual becomes infected, 
E to I, when an infected individual becomes infectious,
I to R, when an infectious individual recovers,
and R to S, when a recovered individual becomes susceptible again.  

**Targets**: A list of  pairs of the form (val, sigma), one per emulated output, used to evaluate implausibility. The 'val' component represents the mean value of the output and 'sigma' represents our uncertainty about it.

**Training data**: The data used to train the emulators. It is obtained by running the model at a given number of parameter sets. 

**Validation data**: The data used to validate the emulators. It is obtained by running the model at a given number of parameter sets (different from those used for the training data).

**Wave**: An iteration of the history matching process.


# (APPENDIX) Appendix {-} 

# Bayes Linear Emulation {#bayes}

In the [emulatorr](https://github.com/Tandethsquire/emulatorr) package we adopt a [Bayes Linear](https://en.wikipedia.org/wiki/Bayes_linear_statistics) approach to build emulators. While a full Bayesian analysis requires specification of a full joint prior probability
distribution to reflect beliefs about uncertain quantities, in the Bayes linear approach expectations are taken as a primitive and only first and second order specifications are needed when defining the prior. Operationally, this means that one just sets prior  mean vectors and covariance matrices for the uncertain quantities,  without having to decide exactly which distribution is responsible for the chosen mean and covariance. A Bayes Linear analysis may therefore be viewed as a pragmatic approach to a full Bayesian analysis, where the task of specifying beliefs has been simplified. As in any Bayesian approach, our priors (mean vectors and covariance matrices) are then adjusted by the observed data.

The Bayes linear approach to statistical inference takes expectation
as primitive. Suppose that there are two collections of random quantities, $B = (B_1,\dots,B_r)$ and 
$D =(1,D_1, \dots D_s)$. Bayes linear analysis involves updating subjective beliefs about $B$
given observation of $D$. In order to do so, prior mean vectors and covariance matrices
for $B$ and $D$ (that is $E[B], E[D], Var[B]$ and $Var[D]$), along with a covariance matrix
between $B$ and $D$ (that is $Cov[B,D]$), must be specified. 

The Bayes linear update formulae for a vector B given a vector D are:
\begin{align}
E_D[B] &= E[B] + Cov[B,D]Var[D]^{-1}(D - E[D]) \\
Var_D[B] &= Var[B] - Cov[B,D]Var[D]^{-1}Cov[D,B] \\
Cov_D[B_1,B_2] &= Cov[B_1,B_2] - Cov[B_1,D]Var[D]^{-1}Cov[D,B_2].
\end{align}
$E_D[B]$ and $Var_D[B]$ are termed the adjusted expectation and variance of $B$ given $D$. $Cov_D[B_1,B_2]$ is termed the adjusted covariance of $B_1$ and $B_2$ given $D$,
where $B_1$ and $B_2$ are subcollections of $B$.
The formula given for $E_D(B)$ represents
the best linear fit for $B$ given $D$ in terms of minimising the expected squared loss
functions $E[(B_k-a_k^TD)^2]$ over choices of $a_k$ for each quantity in $B; k = 1,\dots,r$, that
is, the linear combination of $D$ most informative for $B$. 

# Further issues in emulator structure {#emulstr}

The general structure of a univariate emulator is as follows:
$$f(x) = g(x)^T \beta + u(x),$$
where $g(x)^T \beta$ is the mean function and $u(x)$, with mean zero,  is a [Gaussian process](https://en.wikipedia.org/wiki/Gaussian_process) or a weakly second order stationary process. For a general introduction to univariate emulators we refer to the reader to the article [Bayesian History Matching of Complex Infectious Disease Models Using Emulation: A Tutorial and a Case Study on HIV in Uganda](https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1003968).

In this appendix we briefly discuss some of the choices that can be made in terms of regression functions and of correlation functions. 

## Regression structure
As already seen, in this tutorial we chose to emulate the mean of the process and this is expressed as a linear combination of the regression functions. The simplest possible choice for the regression functions is that of a constant mean: $g(x)=1$ and $\beta$ just a scalar. 
A less trivial structure is given by a polynomial regression. When the input space is one dimensional, this corresponds to $g(x)^T=(1,x,x^2,...,x^p)$ for $p$ a natural number. For example if $p=1$, we are trying to fit a hyperplane, if $p=2$ we fit a quadratic surface. 

The default behaviour of the `emulator_from_data` function in emulatorr is quadratic, while by setting `quadratic=FALSE` one can choose to fit a hyperplane. Here we highlight the method implemented by the `emulator_from_data` function in its default setting (quadratic surface). We will deal with general basis functions in more advances case studies.

### Active variables identification and benefits

The first step is the identification of the active variables, i.e. those variables that have the most explanatory power relative to our data. Restricting our attention to active variables we reduce the dimension of the input space and therefore the complexity of our model. 
Given the data, we start by fitting a model consisting of linear terms and pure quadratic terms, without considering possible interaction terms between parameters. We then perform [stepwise deletion](https://en.wikipedia.org/wiki/Stepwise_regression) on the obtained model, using the [Bayes Information Criterion](https://en.wikipedia.org/wiki/Bayesian_information_criterion) (BIC). This process is repeated till no further deletion can improve the BIC. At this point, any parameters that have either their linear or quadratic term left in the model are designated active variables for the surface.

### Building the model

We now build a new model including all linear, quadratic, and interaction terms in the active variables only. As before, stepwise deletion is used to prune the model. Note that when there are fewer data points than there are terms in the model, stepwise addition is used instead, starting from a purely linear model.

While the first step allowed us to identify the active variables, this final model determines the basis functions and coefficients of the regression surface. The residuals of the final model are computed and used to estimate the correlation length and variance $\sigma^2$ for the correlation structure.

## Correlation structure 

Once the regression functions are chosen, we need to specify the correlation between $u(x)$ and $u(x^\prime)$ for all possible values of $x$ and $x^\prime$. This is a key step, since it will determine how the response $f(x)$ at one parameter set $x$ is affected by the response at any other parameter set $x^\prime$.

A common assumption for the correlation structure is that the variance of $u(x)$ is independent of $x$. If its constant value is denoted by $\sigma^2$, we can then write the correlation of $u(x)$ and $u(x^\prime)$ in the form
$$\sigma^2  c(x,x^{\prime})$$
where $c$, which satisfies $c(x,x)=1$, is the correlation function, or kernel. In our tutorial we also introduced a nugget term $\delta I_{\{x=x^\prime\}}$
that operates on all variables:
$$(1-\delta) c(x,x^{\prime}) + \delta I_{\{x=x^\prime\}}.$$
This term represents the proportion of the overall variance due to the ensemble variability and ensures that the covariance matrix of $u(x)$ is not ill-conditioned, making the computation of its inverse possible. 

The choice of the function $c$ reflects fundamental characteristics of the process $u(x)$, such as stationarity, isotropy and smoothness. For example, $u(x)$ is 
<span class="abbr" title="A Gaussian process u(x) is stationary if 
- for any x and x', the mean of u(x) is the same as the mean of u(x'); 
- the covariance between u(x) and u(x') only depends on the difference x-x'."><abbr title="A Gaussian process u(x) is stationary if 
- for any x and x', the mean of u(x) is the same as the mean of u(x'); 
- the covariance between u(x) and u(x') only depends on the difference x-x'.">
stationary</abbr></span>
if 
$c(x,x^{\prime})$ depends only on $x-x^{\prime}$. In this overview we will always assume stationarity, but non-stationary approaches are also possible. 

From now on we will add a subscript $A$ whenever referring to input points: this indicates that we are operating only on the active parameters for the emulator: that is, parameters that contribute to the regression surface. 

An example of a stationary kernel is the
squared-exponential correlation function, used in this tutorial:
$$c_{\text{SE}}(x,x^{\prime}) = \exp\left(-\sum\limits_{i}\frac{(x_{i,A}-x_{i,A}^{\prime})^2}{\theta_i^2}\right).$$
This function, also called Gaussian correlation function, has the mathematical advantage of being differentiable infinitely many times. In particular, this implies that observing a small continuous fraction of the input space is sufficient to recover the whole process. Such a strong property is not always suitable, since it might be unrealistic to assume that information from a small portion of the input space allows to infer the behaviour of the process everywhere else. 

In such cases, it might be preferable to use the Matérn correlation functions, a family of parametric stationary kernels. The Matérn kernel of order $\nu$ is defined as
$$c_\nu(x,x^{\prime}) = \prod\limits_{i}\frac{(|x_{i,A}-x_{i,A}^{\prime}|/\theta_i)^\nu K_\nu(|x_{i,A}-x_{i,A}^{\prime}|/\theta_i)}{2^{\nu -1}\Gamma(\nu)},$$
where $K_\nu$ is the [modified Bessel function](https://en.wikipedia.org/wiki/Bessel_function#Modified_Bessel_functions:_I%CE%B1,_K%CE%B1) of the second kind and order  $\nu$. Compared to the Gaussian kernel, which is differentiable infinitely many times, $c_\nu$ is 'less smooth', being differentiable only 
$(\left \lceil{\nu}\right \rceil -1)$ times (here $\left \lceil{\nu}\right \rceil$ denotes the ceiling function). The Matérn kernels can be thought as a generalisation of the Gaussian kernel: when $\nu \rightarrow \infty$, the kernel $c_\nu$ converges to $c_{\text{SE}}$. 

When $\nu=1/2$, the kernel $c_{1/2}$ coincides with the so called exponential kernel:
$$c_{\text{exp}}(x,x^{\prime}) = \exp\left(-\sum\limits_{i}\frac{|x_{i,A}-x_{i,A}^{\prime}|}{\theta_i}\right).$$
Note that the sample paths with the exponential kernel are not smooth. 

A third example of stationarity is the rational quadratic kernel, defined by
$$c_{\text{RQ}}(x,x^{\prime}) = \prod\limits_{i}\frac{1}{1+(x_{i,A}-x_{i,A}^{\prime})^2/\theta_i^2} .$$
This correlation function is differentiable infinitely many times, as the Gaussian kernel.

Another key property of kernels is isotropy. A stationary kernel is said to be isotropic (or homogeneous) when it depends only on the distance of $x$ and $x^\prime$, rather than on the full vector $x-x^\prime$. In other words, an isotropic kernel depends on the length of $x-x^\prime$, but not on its direction.
All the stationary kernels mentioned above are isotropic if and only if $\theta_i=\theta_j$ for all $i,j$.

We conclude by recalling the role of the hyperparameters $\theta_i$, which are called correlation lengths. As just seen, when  $\theta_i=\theta$ for all $i$, the kernel is isotropic and therefore has rotational symmetry. In this case, the value $\theta$ has the following interpretation: the larger $\theta$ is, the smoother the local variations of the emulators will be. In the non-isotropic case, $\theta_i<\theta_j$ means that we believe the function to be less smooth with respect to parameter $i$ than parameter $j$.

<!--
# TJ material



```
rmd_files:
    html: ['index.Rmd', 'ch1.Rmd']
    latex: ['index.Rmd', 'ch1.Rmd', 'ch_appendix.Rmd']
output_dir: "docs"
```


-->

<!--chapter:end:index.Rmd-->

